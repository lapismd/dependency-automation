# @lapis-notes/file-explorer

## 0.2.8

### Patch Changes

- Updated dependencies
  [[`1d49473`](https://github.com/lapismd/lapis-notes/commit/1d494734b1e7cc391df2813d7dbc36c50cb7a0b3)]:
  - @lapis-notes/api@0.6.0

## 0.2.7

### Patch Changes

- Updated dependencies
  [[`8b764e6`](https://github.com/lapismd/lapis-notes/commit/8b764e6c150aab1fa55fd365d4874b3b1b4383bd)]:
  - @lapis-notes/api@0.5.0

## 0.2.6

### Patch Changes

- Updated dependencies
  [[`948e198`](https://github.com/lapismd/lapis-notes/commit/948e198dd31cdce777b20e6c7103e3254dfaf8d7),
  [`1a10547`](https://github.com/lapismd/lapis-notes/commit/1a105471657bfe2943d0a0d8d650ffca46bd3feb),
  [`43ff308`](https://github.com/lapismd/lapis-notes/commit/43ff308f4ab66de59c2f896aa7df193452ad59db)]:
  - @lapis-notes/api@0.4.0

## 0.2.5

### Patch Changes

- [#95](https://github.com/lapismd/lapis-notes/pull/95)
  [`8a4d0e0`](https://github.com/lapismd/lapis-notes/commit/8a4d0e02d0642a65ec7441f4fea032739550a6ae)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Admit released Design
  Core 0.13.0 through portable runtime and peer ranges for the mobile workspace
  cohort.
- Updated dependencies
  [[`0ce7e30`](https://github.com/lapismd/lapis-notes/commit/0ce7e3078af8b3f9b132e2b06655a0229e72e346),
  [`8a4d0e0`](https://github.com/lapismd/lapis-notes/commit/8a4d0e02d0642a65ec7441f4fea032739550a6ae)]:
  - @lapis-notes/api@0.3.1

## 0.2.4

### Patch Changes

- Updated dependencies
  [[`0b7ac5a`](https://github.com/lapismd/lapis-notes/commit/0b7ac5a9d6f07dd8a35d7d9fd7de8d9cb076e07b),
  [`84551f9`](https://github.com/lapismd/lapis-notes/commit/84551f9f10ec73ea02fcb71d53131758a9d2d419),
  [`1d9f1d1`](https://github.com/lapismd/lapis-notes/commit/1d9f1d180b38e8248f49abaf8f523fe0cddc28fd)]:
  - @lapis-notes/api@0.3.0

## 0.2.3

### Patch Changes

- [#82](https://github.com/lapismd/lapis-notes/pull/82)
  [`e7b96fb`](https://github.com/lapismd/lapis-notes/commit/e7b96fb7f901c6ffff7e92815b29a82bea5c5264)
  Thanks
  [@lapismd-dependency-bot](https://github.com/apps/lapismd-dependency-bot)! -
  Refresh first-party Lapis dependencies to the published versions recorded in
  this pull request.
- Updated dependencies
  [[`8325b5e`](https://github.com/lapismd/lapis-notes/commit/8325b5eb7adef358ac577b457278a19637c13571),
  [`e7b96fb`](https://github.com/lapismd/lapis-notes/commit/e7b96fb7f901c6ffff7e92815b29a82bea5c5264)]:
  - @lapis-notes/api@0.2.7

## 0.2.2

### Patch Changes

- [#66](https://github.com/lapismd/lapis-notes/pull/66)
  [`6086980`](https://github.com/lapismd/lapis-notes/commit/6086980be8a0d9cf6e697a689b0c17f409afdc3f)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Consume published Design
  Core 0.10.1 so browser hosts can reserve leading and trailing native controls
  and title-bar height, with a continuous divider when sidebars collapse. Keep
  portable registry ranges and existing compatibility.
- Updated dependencies
  [[`6086980`](https://github.com/lapismd/lapis-notes/commit/6086980be8a0d9cf6e697a689b0c17f409afdc3f)]:
  - @lapis-notes/api@0.2.5

## 0.2.1

### Patch Changes

- [#60](https://github.com/lapismd/lapis-notes/pull/60)
  [`fb2eff2`](https://github.com/lapismd/lapis-notes/commit/fb2eff2b11b4a623ea2780f5e3e0f92a0530844b)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Expose the explicit
  Notebook Design Core/UI host modules and admit Design Core 0.9 compatibility,
  including File Explorer so the host resolves one shared Core installation.
  This changes generated host admission metadata and dependency compatibility,
  not the API runtime interface; retain the 0.2 API peer cohort. Full host
  qualification remains required before release.

  Add a public Vite renderer adapter that binds plugin compiler imports to the
  admitted versioned Svelte namespace and resolves those entries through the
  shared host runtime. Expose the required Markdown and CodeMirror host modules
  while keeping private imports and renderer version mismatches rejected.
- Updated dependencies
  [[`fb2eff2`](https://github.com/lapismd/lapis-notes/commit/fb2eff2b11b4a623ea2780f5e3e0f92a0530844b)]:
  - @lapis-notes/api@0.2.4

## 0.2.0

### Minor Changes

- [`55be8dc`](https://github.com/lapismd/lapis-notes/commit/55be8dce6f7b19b0e8036be86a3cf5305db25317)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Let file-view plugins
  contribute a fileIcon ID for their filename patterns or registered extensions.
  Add App-owned SVG and icon-pack registration with plugin lifecycle cleanup,
  preserve legacy icon registrations, and refresh Explorer artwork on editor,
  plugin and file changes.

  Release the scoped Design Core resolver first and raise the dependent minimum
  ranges to the releases containing these contracts before publishing consumers.

  Upgrade API-owned Zod to the patched package while retaining its public v3
  schema entry for compatibility.

### Patch Changes

- [`fbba8d4`](https://github.com/lapismd/lapis-notes/commit/fbba8d48498c34939fec475e6bed67a682045820)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Retain plugin-state and
  compatibility-file drafts through close and conflict recovery, drain admitted
  plugin/file operations before teardown, and preserve Properties mutations
  after initial read failures.

- [`d8946b9`](https://github.com/lapismd/lapis-notes/commit/d8946b941569484b813eb0c1e8b1c5729fffc1a7)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Add owned
  diagnostic-resource navigation and themed recovery-banner actions. Accept
  Design Core 0.5.1 alongside the existing 0.4 range.

- [`023259d`](https://github.com/lapismd/lapis-notes/commit/023259d96d4ff0414fec6427924ed917f89405a3)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Add an optional exclusive
  file-creation transport and route Explorer new-note actions through the
  FileManager creation intent. Preserve existing destinations on collisions and
  keep legacy Vault creation semantics explicit.

- [`717f0ff`](https://github.com/lapismd/lapis-notes/commit/717f0ff3956a5d33cba10311fca9c41a06e53b21)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Connect the existing
  Explorer file-drop surface to FileManager new-file creation. Preserve binary
  bytes and existing destinations, validate bounded input before reading it, and
  retain App admission through asynchronous import and projection.

- Require released Design Core 0.6 for the close-guard, plugin-flush and
  centered panel contracts used by current source. Retain portable registry
  dependency ranges for the shared application runtime.

- [`bac3e5e`](https://github.com/lapismd/lapis-notes/commit/bac3e5eda6f467dbc86ec88c9f27a275f2b27953)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Expose optional
  implemented system trash through the neutral native adapter with explicit
  unsupported fallback and validated acknowledgements. Attribute Explorer
  native/copy feedback to its owning App and reject unavailable clipboard
  support without reporting success.

- [`501c50e`](https://github.com/lapismd/lapis-notes/commit/501c50e049264560e13e29c75a74c089922c7297)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Project owned App notices
  through the existing workspace notification UI and retire their subscription
  on host disposal. Pass the explicit Explorer App when reporting file-action
  failures.

- [`98b333f`](https://github.com/lapismd/lapis-notes/commit/98b333f73ff5ba8d5f28c52e4e3a2ceaa5ade0fb)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Protect and flush
  registered file writers before FileManager trash or deletion, including folder
  descendants. Route Explorer deletion through that guard so failed writes
  retain the file and dirty draft until explicit recovery.
- Updated dependencies
  [[`bdd4923`](https://github.com/lapismd/lapis-notes/commit/bdd492357135de2cc0175fa42413709b2a38cd63),
  [`86e85f6`](https://github.com/lapismd/lapis-notes/commit/86e85f6e814430c1755147c913eb91090a439bf4),
  [`631aeec`](https://github.com/lapismd/lapis-notes/commit/631aeec539e2fb061dc80c5c3a30a248ee15c529),
  [`fdee7e4`](https://github.com/lapismd/lapis-notes/commit/fdee7e4defde17a1009e16138d78c93c3ead8e2f),
  [`a91d5e2`](https://github.com/lapismd/lapis-notes/commit/a91d5e2eb5ec037029f6a7a2df316a9bd9440af7),
  [`fbba8d4`](https://github.com/lapismd/lapis-notes/commit/fbba8d48498c34939fec475e6bed67a682045820),
  [`d8946b9`](https://github.com/lapismd/lapis-notes/commit/d8946b941569484b813eb0c1e8b1c5729fffc1a7),
  [`ebf033a`](https://github.com/lapismd/lapis-notes/commit/ebf033af0fc0752be5ce5ffa7d55784163d291b4),
  [`023259d`](https://github.com/lapismd/lapis-notes/commit/023259d96d4ff0414fec6427924ed917f89405a3),
  [`63a5e7f`](https://github.com/lapismd/lapis-notes/commit/63a5e7fe40eea45762b5842b588c742076c7dd1d),
  [`2bffe48`](https://github.com/lapismd/lapis-notes/commit/2bffe484b38761af197afe7ab9b0d7b3affb50d7),
  [`86f6316`](https://github.com/lapismd/lapis-notes/commit/86f63166c3d5be648c595ef4e230ea6c4081bc48),
  [`edf1d76`](https://github.com/lapismd/lapis-notes/commit/edf1d76f4f3aa0442c1d9153d812f29b7d14e5c2),
  [`b3be91d`](https://github.com/lapismd/lapis-notes/commit/b3be91daecbd43187bacf8cfdc39f8311d700720),
  [`5ef0a63`](https://github.com/lapismd/lapis-notes/commit/5ef0a6331c1b846b70357f990d919977a561112c),
  [`bac3e5e`](https://github.com/lapismd/lapis-notes/commit/bac3e5eda6f467dbc86ec88c9f27a275f2b27953),
  [`978b987`](https://github.com/lapismd/lapis-notes/commit/978b987ba4c95408a63e49fad11bc44bab020758),
  [`ad4490c`](https://github.com/lapismd/lapis-notes/commit/ad4490ca1cd808002765582a17a5c81fa5335e0d),
  [`74f544e`](https://github.com/lapismd/lapis-notes/commit/74f544e2aa8a967524c0c218f3db7e1a495a1a17),
  [`55be8dc`](https://github.com/lapismd/lapis-notes/commit/55be8dce6f7b19b0e8036be86a3cf5305db25317),
  [`501c50e`](https://github.com/lapismd/lapis-notes/commit/501c50e049264560e13e29c75a74c089922c7297),
  [`98b333f`](https://github.com/lapismd/lapis-notes/commit/98b333f73ff5ba8d5f28c52e4e3a2ceaa5ade0fb),
  [`535a6cc`](https://github.com/lapismd/lapis-notes/commit/535a6cc7b39f397cf8761a06db7b831386121928),
  [`8a27bc3`](https://github.com/lapismd/lapis-notes/commit/8a27bc36a7a7fa81594e517908a6f5ed8ca77313),
  [`109e208`](https://github.com/lapismd/lapis-notes/commit/109e208a63253dcc1a7abad3fd5a9b13c39d3def),
  [`1e64589`](https://github.com/lapismd/lapis-notes/commit/1e6458922b486c07f36a5bc7d85d020b5805cd49),
  [`f828eae`](https://github.com/lapismd/lapis-notes/commit/f828eaeba8411aa342d7ab4954393e84612af2f3)]:
  - @lapis-notes/api@0.2.0

## 0.1.3

### Patch Changes

- [#36](https://github.com/lapismd/lapis-notes/pull/36)
  [`17060a1`](https://github.com/lapismd/lapis-notes/commit/17060a1df152c9fc2302c93767cd7172868ff030)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Consume published Design
  Core 0.5.0 with prepared browser CSS and bundled font assets through normal
  npm ranges.
- Updated dependencies
  [[`17060a1`](https://github.com/lapismd/lapis-notes/commit/17060a1df152c9fc2302c93767cd7172868ff030)]:
  - @lapis-notes/api@0.1.5

## 0.1.2

### Patch Changes

- [#4](https://github.com/lapismd/lapis-notes/pull/4)
  [`c1ad3c4`](https://github.com/lapismd/lapis-notes/commit/c1ad3c4acee2eac1ae87c22f66e946d2e0db3bf2)
  Thanks [@stevejuma](https://github.com/stevejuma)! - Require published Design
  Core 0.3.2 for native window-controls spacing, bold settings headings,
  selected-tab indicators and mobile shell teardown. Consume the npm release
  through portable semver ranges and lockfile integrity.

- Updated dependencies
  [[`39f886d`](https://github.com/lapismd/lapis-notes/commit/39f886d017a28d916b3f6cac7d08b7723a04f45b),
  [`c1ad3c4`](https://github.com/lapismd/lapis-notes/commit/c1ad3c4acee2eac1ae87c22f66e946d2e0db3bf2),
  [`1e949fc`](https://github.com/lapismd/lapis-notes/commit/1e949fc9d51b795a50760e1146a9599602746c6b)]:
  - @lapis-notes/api@0.1.2

## 0.1.1

### Patch Changes

- Reuse the active landing leaf when opening a file through File Explorer.

- Updated dependencies []:
  - @lapis-notes/api@0.1.1

## 0.1.0

### Minor Changes

- First public npm release of the reusable Lapis File Explorer plugin.
